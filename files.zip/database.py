"""
database.py — Google Sheets + Google Drive integration
Handles: connect, append rows, fetch records as DataFrame, upload images to Drive.
"""

import os
import json
import io
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from dotenv import load_dotenv

load_dotenv()

# ── Config ─────────────────────────────────────────────────────────────────────
SHEET_NAME    = "Union_Records"
DRIVE_FOLDER  = "Union_Grievance_Images"

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

COLUMN_HEADERS = [
    "timestamp",
    "employee_name",
    "employee_id",
    "date",
    "case_type",
    "article_violated",
    "description",
    "source_file",
    "image_url",
]


# ── Credentials ────────────────────────────────────────────────────────────────
def _get_credentials() -> Credentials:
    creds_json = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON")
    if creds_json:
        try:
            creds_dict = json.loads(creds_json)
        except json.JSONDecodeError as e:
            raise ValueError(f"GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON: {e}")
        return Credentials.from_service_account_info(creds_dict, scopes=SCOPES)

    creds_file = os.getenv("GOOGLE_SERVICE_ACCOUNT_FILE", "service_account.json")
    if os.path.exists(creds_file):
        return Credentials.from_service_account_file(creds_file, scopes=SCOPES)

    raise ValueError(
        "No Google credentials found. Set either:\n"
        "  GOOGLE_SERVICE_ACCOUNT_JSON (full JSON string)\n"
        "  GOOGLE_SERVICE_ACCOUNT_FILE (path to JSON file)"
    )


def _get_gspread_client() -> gspread.Client:
    return gspread.authorize(_get_credentials())


def _get_drive_service():
    return build("drive", "v3", credentials=_get_credentials())


# ── Google Drive ───────────────────────────────────────────────────────────────
def _get_or_create_drive_folder(drive_service) -> str:
    """Find or create the Union_Grievance_Images folder. Returns folder ID."""
    query = (
        f"name='{DRIVE_FOLDER}' "
        f"and mimeType='application/vnd.google-apps.folder' "
        f"and trashed=false"
    )
    results = drive_service.files().list(q=query, fields="files(id, name)").execute()
    files = results.get("files", [])

    if files:
        return files[0]["id"]

    folder_meta = {
        "name": DRIVE_FOLDER,
        "mimeType": "application/vnd.google-apps.folder",
    }
    folder = drive_service.files().create(body=folder_meta, fields="id").execute()
    folder_id = folder["id"]

    drive_service.permissions().create(
        fileId=folder_id,
        body={"type": "anyone", "role": "reader"},
    ).execute()

    return folder_id


def upload_image_to_drive(image_bytes: bytes, filename: str, mime_type: str = "image/jpeg") -> str | None:
    """
    Upload an image to Union_Grievance_Images in Google Drive.

    Args:
        image_bytes: Raw image bytes
        filename:    Desired filename (e.g. "UPS-00123_2024-01-15.jpg")
        mime_type:   MIME type of the image

    Returns:
        Shareable view URL on success, None on failure.
    """
    try:
        drive_service = _get_drive_service()
        folder_id = _get_or_create_drive_folder(drive_service)

        file_meta = {"name": filename, "parents": [folder_id]}
        media = MediaIoBaseUpload(
            io.BytesIO(image_bytes),
            mimetype=mime_type,
            resumable=False,
        )
        uploaded = drive_service.files().create(
            body=file_meta,
            media_body=media,
            fields="id",
        ).execute()

        file_id = uploaded["id"]

        # Anyone with the link can view
        drive_service.permissions().create(
            fileId=file_id,
            body={"type": "anyone", "role": "reader"},
        ).execute()

        return f"https://drive.google.com/file/d/{file_id}/view"

    except Exception as e:
        print(f"[database.py] upload_image_to_drive error: {e}")
        return None


# ── Google Sheets ──────────────────────────────────────────────────────────────
def _get_or_create_sheet() -> gspread.Worksheet:
    """Open Union_Records sheet, creating it with headers if needed."""
    client = _get_gspread_client()

    try:
        spreadsheet = client.open(SHEET_NAME)
    except gspread.SpreadsheetNotFound:
        spreadsheet = client.create(SHEET_NAME)
        spreadsheet.share(None, perm_type="anyone", role="writer")
        print(f"Created new spreadsheet: {SHEET_NAME}")

    worksheet = spreadsheet.sheet1
    existing = worksheet.get_all_values()

    if not existing:
        worksheet.append_row(COLUMN_HEADERS, value_input_option="RAW")
    elif existing[0] != COLUMN_HEADERS:
        # Add image_url column to sheets created before this update
        if "image_url" not in existing[0]:
            worksheet.delete_rows(1)
            worksheet.insert_row(COLUMN_HEADERS, index=1)

    return worksheet


def append_record(record: dict) -> bool:
    """
    Append a validated record as a new row in the Google Sheet.
    image_url is optional and defaults to empty string.
    """
    try:
        worksheet = _get_or_create_sheet()
        row = [str(record.get(col, "")) for col in COLUMN_HEADERS]
        worksheet.append_row(row, value_input_option="USER_ENTERED")
        return True
    except Exception as e:
        print(f"[database.py] append_record error: {e}")
        return False


def get_all_records() -> pd.DataFrame | None:
    """Fetch all records as a DataFrame, sorted newest first."""
    try:
        worksheet = _get_or_create_sheet()
        data = worksheet.get_all_records(expected_headers=COLUMN_HEADERS)

        if not data:
            return pd.DataFrame(columns=COLUMN_HEADERS)

        df = pd.DataFrame(data)
        for col in COLUMN_HEADERS:
            if col not in df.columns:
                df[col] = ""

        if "timestamp" in df.columns:
            df = df.sort_values("timestamp", ascending=False).reset_index(drop=True)

        return df[COLUMN_HEADERS]

    except Exception as e:
        print(f"[database.py] get_all_records error: {e}")
        return None


def search_records(query: str, search_fields: list | None = None) -> pd.DataFrame | None:
    """Filter records by query string across specified fields."""
    if search_fields is None:
        search_fields = ["employee_name", "employee_id"]

    df = get_all_records()
    if df is None or df.empty:
        return df

    query = query.strip().lower()
    if not query:
        return df

    mask = pd.Series(False, index=df.index)
    for field in search_fields:
        if field in df.columns:
            mask |= df[field].str.lower().str.contains(query, na=False)

    return df[mask].reset_index(drop=True)


def delete_record_by_employee_id(employee_id: str) -> int:
    """Delete all sheet rows matching a given employee_id. Returns count deleted."""
    try:
        worksheet = _get_or_create_sheet()
        all_values = worksheet.get_all_values()
        headers = all_values[0] if all_values else []

        try:
            id_col_idx = headers.index("employee_id") + 1
        except ValueError:
            return 0

        rows_to_delete = []
        for i, row in enumerate(all_values[1:], start=2):
            if len(row) >= id_col_idx and row[id_col_idx - 1].strip() == employee_id.strip():
                rows_to_delete.append(i)

        for row_idx in sorted(rows_to_delete, reverse=True):
            worksheet.delete_rows(row_idx)

        return len(rows_to_delete)

    except Exception as e:
        print(f"[database.py] delete_record error: {e}")
        return 0


# ── CLI test ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Testing Google Sheets + Drive connection...\n")

    try:
        worksheet = _get_or_create_sheet()
        print(f"✓ Sheets connected: {worksheet.spreadsheet.title}")

        drive_service = _get_drive_service()
        folder_id = _get_or_create_drive_folder(drive_service)
        print(f"✓ Drive folder ready: '{DRIVE_FOLDER}' (id: {folder_id})")

        # Upload a tiny test PNG
        import base64
        tiny_png = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwADhQGAWjR9awAAAABJRU5ErkJggg=="
        )
        url = upload_image_to_drive(tiny_png, "test_upload.png", "image/png")
        print(f"✓ Drive upload test: {url}")

        test_record = {
            "timestamp": "2024-01-01 12:00:00",
            "employee_name": "Test Employee",
            "employee_id": "TEST-001",
            "date": "2024-01-01",
            "case_type": "Grievance",
            "article_violated": "Article 99",
            "description": "Test record with image — safe to delete.",
            "source_file": "test_upload.png",
            "image_url": url or "",
        }
        success = append_record(test_record)
        print(f"✓ Append test: {'SUCCESS' if success else 'FAILED'}")

        df = get_all_records()
        print(f"✓ Fetch test: {len(df)} records found")
        if not df.empty:
            print(df[["employee_name", "image_url"]].head())

    except Exception as e:
        print(f"✗ Test failed: {e}")
        print("\nMake sure google-api-python-client is installed:")
        print("  pip install google-api-python-client")
